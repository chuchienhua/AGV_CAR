

#include "ivam_sicks300.h"



ivam_sick551::ivam_sick551()
{
  ros::NodeHandle nhPriv("~");

  ros::NodeHandle nhPriv2("~");


  bool useTCP = false;
  std::string hostname;
  hostname = "140.118.221.131";
  useTCP = true;
  std::string port;
  nhPriv.param<std::string>("port", port, "2111");

//----------------//
 bool useTCP_2 = false;
 std::string hostname_2;
  hostname_2 = "140.118.221.135";
  std::string port_2;
  port_2 = "2112";

  int timelimit_2;
  nhPriv2.param("timelimit", timelimit_2, 5);

  bool subscribe_datagram_2;
  int device_number_2;
  nhPriv2.param("subscribe_datagram", subscribe_datagram_2, false);
  nhPriv2.param("device_number", device_number_2, 0);

  sick_tim::SickTim5512050001Parser* parser_2 = new sick_tim::SickTim5512050001Parser();

  double param_2;
  if (nhPriv2.getParam("range_min", param_2))
  {
    parser_2->set_range_min(param_2);
  }

  if (nhPriv2.getParam("range_max", param_2))
  {
    parser_2->set_range_max(param_2);
  }
  if (nhPriv2.getParam("time_increment", param_2))
  {
    parser_2->set_time_increment(param_2);
  }

    sick_tim::SickTimCommon* s_2 = NULL;

  int result_2 = sick_tim::ExitError;
  //---------------//

  

  int timelimit;
  nhPriv.param("timelimit", timelimit, 5);

  bool subscribe_datagram;
  int device_number;
  nhPriv.param("subscribe_datagram", subscribe_datagram, false);
  nhPriv.param("device_number", device_number, 0);

  sick_tim::SickTim5512050001Parser* parser = new sick_tim::SickTim5512050001Parser();

  double param;
  if (nhPriv.getParam("range_min", param))
  {
    parser->set_range_min(param);
  }
  if (nhPriv.getParam("range_max", param))
  {
    parser->set_range_max(param);
  }
  if (nhPriv.getParam("time_increment", param))
  {
    parser->set_time_increment(param);
  }

  sick_tim::SickTimCommon* s = NULL;

  int result = sick_tim::ExitError;

      s = new sick_tim::SickTimCommonTcp(hostname, port, timelimit, parser);
      s_2 = new sick_tim::SickTimCommonTcp(hostname_2, port_2, timelimit_2, parser_2);

	scan_data_publisher_ = nodeHandle_.advertise<sensor_msgs::LaserScan>("scan", 10);
	
}

ivam_sick551::~ivam_sick551()
{

}

void ivam_sick551::update()
{


	unsigned int numRanges_1;
	unsigned int numRanges_2;
	unsigned int scanNum_1;
	unsigned int scanNum_2;



	for ( int i=0; i < device_list.size(); i++ ){

		if( device_list[i].connected_ != 0 ) {

			ROS_INFO_STREAM("Executing connect cmd " << device_list[i].connect_cmd_ << "...");

			system(device_list[i].connect_cmd_.c_str());


			ROS_INFO("Opening connection to Sick300-laser...");

			device_list[i].connected_ = device_list[i].serial_comm_.connect((device_list[i].device_name_), device_list[i].baud_rate_);

			if (device_list[i].connected_ == 0) {
				ROS_INFO("Sick300 connected.");
			} 
			else {
				ROS_ERROR("Sick300 not connected, will try connecting again in 500 msec...");
				std::this_thread::sleep_for(std::chrono::milliseconds(500));
			}

		}
	}
	

	int status_1 = -1;
	int status_2 = -1;

	
		
	if(device_list[0].connected_ == 0){

		status_1 = device_list[0].serial_comm_.readData();

	    if (status_1 == -2) {
	      ROS_ERROR("Error in communication, closing connection and waiting 500 msec...");
	      device_list[0].serial_comm_.disconnect();
	      std::this_thread::sleep_for(std::chrono::milliseconds(500));
	      device_list[0].connected_ = -1;
	    } 
		

	}


	if(device_list.size() == 2){

		if(device_list[1].connected_ == 0){

			status_2 = device_list[1].serial_comm_.readData();

	    	if (status_2 == -2) {

	    		ROS_ERROR("Error in communication, closing connection and waiting 500 msec...");

	    		device_list[1].serial_comm_.disconnect();

	    		std::this_thread::sleep_for(std::chrono::milliseconds(500));

	    		device_list[1].connected_ = -1;

	    	} 

		}
	}


	if(status_1 == 0){

		ranges_1 = device_list[0].serial_comm_.getRanges();
		numRanges_1 = device_list[0].serial_comm_.getNumRanges();

		check_device_1 = 1;

	}

	if(status_2 == 0){

	    ranges_2 = device_list[1].serial_comm_.getRanges();
	    numRanges_2 = device_list[1].serial_comm_.getNumRanges();

	    check_device_2 = 1;
	    
	}
    
	if(device_list.size() == 2){

		if(check_device_1 && check_device_2){

			int store_index = 0;


			//why end_scan to start_scan? because they put laser inverse.
            for (unsigned int i = end_scan_-1; i > start_scan_; i--) {
               	scan_data_.ranges[store_index] = ranges_1[i];
               	store_index += 1;
            }


            for (unsigned int i = end_scan_-1; i > start_scan_; i--) {
               	scan_data_.ranges[store_index] = ranges_2[i];
               	store_index += 1;
            }

            scan_data_.header.stamp = device_list[0].serial_comm_.getReceivedTime();

            scan_data_publisher_.publish(scan_data_);

			check_device_1 = 0;
			check_device_2 = 0;


		}

	}
	else{


		int store_index = 0;

		if(status_1 == 0){
            for (unsigned int i = end_scan_-1; i > start_scan_; i--) {
               	scan_data_.ranges[store_index] = ranges_1[i];
               	store_index += 1;

               	scan_data_.header.stamp = device_list[0].serial_comm_.getReceivedTime();
               	scan_data_publisher_.publish(scan_data_);
            }
		}

	}
}

void ivam_sick551::broadcast_transform() {

  if (send_transform_) {

  	tf_broadcaster_.sendTransform(tf::StampedTransform( transform_laser_1, ros::Time::now(), "base_link", frame_id_1_));

  	tf_broadcaster_.sendTransform(tf::StampedTransform( transform_laser_2, ros::Time::now(), "base_link", frame_id_2_));

  }
  
}

int main(int argc, char **argv)
{

	ros::init(argc, argv, "ivam_sicks300");
	ros::Time::init();

	if(argc < 3){

		ROS_INFO("usage: <IP address> [<port number>] .....[<baud rate>]");

		return 0;

	}
	else{
		

		//Create Struct to stroge device info

		if(argc == 3) {

			DEVICE dev_buf;
			dev_buf.device_name_ = argv[1];
			dev_buf.baud_rate_   = std::atoi(argv[argc-1]);
			dev_buf.connected_ = -1;
			device_list.push_back(dev_buf);

		}
		else if(argc == 4) {

			DEVICE dev_buf_1;
			dev_buf_1.device_name_ = argv[1];
			dev_buf_1.baud_rate_   = std::atoi(argv[argc-1]);
			dev_buf_1.connected_ = -1;
			device_list.push_back(dev_buf_1);

			DEVICE dev_buf_2;
			dev_buf_2.device_name_ = argv[2];
			dev_buf_2.baud_rate_   = std::atoi(argv[argc-1]);
			dev_buf_2.connected_ = -1;
			device_list.push_back(dev_buf_2);


		}
		else {

			ROS_INFO("usage: [<Device name>] .....[<Baud rate>]");

			return 0;

		}

	}

	ROS_INFO("Num of Device: %d", device_list.size());

	for(int i=0; i<device_list.size(); i++){

		ROS_INFO("Device[%d] name: %s", i, device_list[i].device_name_);

		ROS_INFO("Device[%d] baud rate: %d", i, device_list[i].baud_rate_);

	}


    ivam_sick551 sickS300;




	while (ros::ok()) {

		sickS300.update();

		sickS300.broadcast_transform();

		ros::spinOnce();

	}

	ROS_INFO("Laser shut down.");

	return 0;

}
