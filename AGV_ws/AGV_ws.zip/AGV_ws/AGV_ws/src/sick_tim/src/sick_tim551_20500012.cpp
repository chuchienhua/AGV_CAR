/*
 * Copyright (C) 2013, Osnabrück University
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of Osnabrück University nor the names of its
 *       contributors may be used to endorse or promote products derived from
 *       this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 *  Created on: 14.11.2013
 *
 *      Author:
 *         Martin Günther <mguenthe@uos.de>
 *
 */

#include <sick_tim/sick_tim_common_usb.h>
#include <sick_tim/sick_tim_common_tcp.h>
#include <sick_tim/sick_tim_common_mockup.h>
#include <sick_tim/sick_tim551_2050001_parser.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <string.h>
#include <vector>

#include <ros/ros.h>
#include <sensor_msgs/LaserScan.h>
#include <std_msgs/String.h>

#include <diagnostic_updater/diagnostic_updater.h>
#include <diagnostic_updater/publisher.h>

#include <dynamic_reconfigure/server.h>
#include <sick_tim/SickTimConfig.h>

#include <tf/transform_broadcaster.h>

int main(int argc, char **argv)
{



	ros::init(argc, argv, "sick_tim551_20500012");
	ros::NodeHandle nh_;

  //ros::Publisher scan_data_publisher_ =  nh_.advertise<sensor_msgs::LaserScan>("scan", 1000);
	ros::Publisher scan_data_publisher_ =  nh_.advertise<sensor_msgs::LaserScan>("scan_2", 1000);
	ros::NodeHandle nhPriv("~");

	ros::NodeHandle nhPriv2("~");

	bool DeviceNum2 = false;
	if(argc == 3)
	{
		DeviceNum2 = true;
	}
	else if(argc < 2)
	{
		ROS_INFO("usage: [<IP_1>] ( [<IP_2>] )");

        return 0;
	}

	sensor_msgs::LaserScan scan_data_;

	tf::TransformBroadcaster tf_broadcaster_;
	tf::Vector3 transform_vector_;
	tf::Transform transform_laser_1;
	tf::Transform transform_laser_2;
	transform_laser_1.setOrigin(tf::Vector3(-0.24568, -0.1458, 0.0));
	tf::Quaternion q_1;
	q_1.setRPY(0, 0, -2.335);
	transform_laser_1.setRotation(q_1);


	//transform_laser_2.setOrigin(tf::Vector3(-0.230052, -0.130052, 0.0));
	transform_laser_2.setOrigin(tf::Vector3(-0.28, -0.14, 0.0));
	tf::Quaternion q_2;
	//q_2.setRPY(0, 0, -2.338);
	q_2.setRPY(0, 0, -2.38);
	transform_laser_2.setRotation(q_2);

	unsigned int field_of_view_;
	unsigned int start_scan_;
	unsigned int end_scan_;
	float *ranges_1;
	float *ranges_2;
	std::string frame_id_1_;
	std::string frame_id_2_;
	frame_id_1_ = std::string("base_laser_link");
	frame_id_2_ = std::string("base_laser_link_2");

	field_of_view_ = (unsigned int) (270 * 3.0); // angle increment is .5 degrees
	field_of_view_ <<= 1;
	field_of_view_ >>= 1; // round to a multiple of two
	start_scan_ = 0;
	end_scan_ = 810;
	std::cout<<start_scan_<<end_scan_ <<std::endl;

	// scan_data_.header.frame_id = frame_id_1_;
	// scan_data_.angle_min = -2.35619449019;
	// scan_data_.angle_max = 2.35619449019;
	// scan_data_.angle_increment = (float) (0.33 / 180. * M_PI);
	// scan_data_.time_increment = 0.000061722;
	// scan_data_.scan_time = 0.066667;
	// scan_data_.range_min = 0.05;
	// scan_data_.range_max = 25.0;

	scan_data_.header.frame_id = frame_id_2_;
	scan_data_.angle_min = -2.35619449019;
	scan_data_.angle_max = 2.35572;
	scan_data_.angle_increment = 0.00581718;
	scan_data_.time_increment = 0.0000617284;
	scan_data_.scan_time = 0.0666667;
	scan_data_.range_min = 0.05;
	scan_data_.range_max = 25.0;

	if(DeviceNum2){
		scan_data_.ranges.resize(field_of_view_*2);
		scan_data_.intensities.resize(field_of_view_*2);
	}
	else
	{
		scan_data_.ranges.resize(field_of_view_);
		scan_data_.intensities.resize(field_of_view_);

	}



	// check for TCP - use if ~hostname is set.
	bool useTCP = false;
	std::string hostname;

	hostname = argv[1];
	useTCP = true;
	std::string port;
	nhPriv.param<std::string>("port", port, "2111");
	std::cout<<"hostname "<<hostname<<std::endl;

	int timelimit;
	nhPriv.param("timelimit", timelimit, 5);
	std::cout<<timelimit<<std::endl;
	bool subscribe_datagram;
	int device_number;
	nhPriv.param("subscribe_datagram", subscribe_datagram, false);
	nhPriv.param("device_number", device_number, 0);
	// std::cout<<subscribe_datagram <<std::endl;
	// std::cout<<device_number <<std::endl;
	sick_tim::SickTim5512050001Parser* parser = new sick_tim::SickTim5512050001Parser();

	double param;
	if (nhPriv.getParam("range_min", param))
	{
		parser->set_range_min(param);
	}
	if (nhPriv.getParam("range_max", param))
	{
		parser->set_range_max(param);
	}
	if (nhPriv.getParam("time_increment", param))
	{
		parser->set_time_increment(param);
	}


	//----------------//
	bool useTCP_2 = false;
	std::string hostname_2;
	std::string port_2;
	int timelimit_2;
	double param_2;
	sick_tim::SickTim5512050001Parser* parser_2;


	if(DeviceNum2){
		hostname_2 = argv[2];

		nhPriv2.param<std::string>("port", port_2, "2112");


		nhPriv2.param("timelimit", timelimit_2, 5);

		bool subscribe_datagram_2;
		int device_number_2;
		nhPriv2.param("subscribe_datagram", subscribe_datagram_2, false);
		nhPriv2.param("device_number", device_number_2, 1);

		parser_2 = new sick_tim::SickTim5512050001Parser();


		if (nhPriv2.getParam("range_min", param_2))
		{
			parser_2->set_range_min(param_2);
		}

		if (nhPriv2.getParam("range_max", param_2))
		{
			parser_2->set_range_max(param_2);
		}
		if (nhPriv2.getParam("time_increment", param_2))
		{
			parser_2->set_time_increment(param_2);
		}
	}
	sick_tim::SickTimCommon* s_2 = NULL;

	int result_2 = sick_tim::ExitError;

	sick_tim::SickTimCommon* s = NULL;

	int result = sick_tim::ExitError;

	//---------------//
	while (ros::ok())
	{
		// Atempt to connect/reconnect
		if (subscribe_datagram){

			s = new sick_tim::SickTimCommonMockup(parser);
			std::cout<<"FIrSt"<<std::endl;
		}
		else if (useTCP){
			s = new sick_tim::SickTimCommonTcp(hostname, port, timelimit, parser);
			if(DeviceNum2)
				s_2 = new sick_tim::SickTimCommonTcp(hostname_2, port_2, timelimit_2, parser_2);
			std::cout<<"second"<<std::endl;
		}

		result = s->init();

		if(DeviceNum2)
			result_2 = s_2->init();

		//while(ros::ok() && (result == sick_tim::ExitSuccess)&&(result_2 == sick_tim::ExitSuccess)){
		while(ros::ok() && (result == sick_tim::ExitSuccess)){

			result = s->loopOnce();
			if(DeviceNum2)
				result_2 = s_2->loopOnce();
			//std::cout<<s->msg <<std::endl;
			// std::cout<<s_2->msg <<std::endl;

			int store_index = 0;
			for (unsigned int i = 0; i < end_scan_; i++) {
				scan_data_.ranges[store_index] = s->msg.ranges[i];
				// std::cout<<	scan_data_.ranges[store_index]<<std::endl;
				store_index += 1;
			}
			scan_data_.header.stamp = s->msg.header.stamp;

			if(DeviceNum2){
				for (unsigned int i = 0; i < end_scan_; i++) {
					scan_data_.ranges[store_index] = s_2->msg.ranges[i];
					//std::cout<<	scan_data_.ranges[store_index]<<std::endl;
					store_index += 1;
				}
				scan_data_.header.stamp = s_2->msg.header.stamp;
			}

			scan_data_publisher_.publish(scan_data_);


			//tf_broadcaster_.sendTransform(tf::StampedTransform( transform_laser_1, ros::Time::now(), "base_link", frame_id_2_));
			tf_broadcaster_.sendTransform(tf::StampedTransform( transform_laser_2, ros::Time::now(), "base_link", frame_id_2_));
			if(DeviceNum2)
				tf_broadcaster_.sendTransform(tf::StampedTransform( transform_laser_2, ros::Time::now(), "base_link", frame_id_2_));




			//std::cout<<scan_data_ <<std::endl;

			ros::spinOnce();
		}


std::cout<<"=================="<<std::endl;


		delete s;

		if (result == sick_tim::ExitFatal)
			return result;

		if (ros::ok() && !subscribe_datagram && !useTCP)
			ros::Duration(1.0).sleep(); // Only attempt USB connections once per second



	}

	delete parser;
	return result;
}
