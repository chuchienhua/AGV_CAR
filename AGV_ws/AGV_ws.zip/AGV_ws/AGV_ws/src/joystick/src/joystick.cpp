#include "joystick.h"

Joystick::Joystick(char *joystick_dev)
{
	active = false;
	btn_id = 0;
	btn_last = 0;
	isPause = false;

	leftAxis.x = 0.0;
	leftAxis.y = 0.0;
	leftAxis.r = 0.0;
	leftAxis.theta = 0.0;
	rightAxis.x = 0.0;
	rightAxis.y = 0.0;
	rightAxis.r = 0.0;
	rightAxis.theta = 0.0;

	joystick_fd = 0;
	joystick_ev = new js_event();
	joystick_st = new joystick_state();
	joystick_fd = open(joystick_dev, O_RDONLY | O_NONBLOCK);
	if (joystick_fd > 0) {
		ioctl(joystick_fd, JSIOCGNAME(256), name);
		ioctl(joystick_fd, JSIOCGVERSION, &version);
		ioctl(joystick_fd, JSIOCGAXES, &axes);
		ioctl(joystick_fd, JSIOCGBUTTONS, &buttons);
		cout << "   Name: " << name << endl;
		cout << "Version: " << version << endl;
		cout << "   Axes: " << int(axes) << endl;
		cout << "Buttons: " << int(buttons) << endl;

		for(int i=0; i<axes; i++)
			joystick_st->axis.push_back(0);
		for(int i=0; i<buttons; i++)
			joystick_st->button.push_back(0);

		//cout<<joystick_st->axis.size()<<endl;
		//cout<<joystick_st->button.size()<<endl;
		active = true;
	}

	Point_data_publisher_ = nodeHandle_.advertise<JoyStick::joystick>("joystick", 10);

	receive_thread_ = new boost::thread(boost::bind(&Joystick::RevProcess, this, 0.001));
}

Joystick::~Joystick(){
	if (joystick_fd > 0) {
		active = false;
		close(joystick_fd);
	}
	delete joystick_st;
	delete joystick_ev;
	joystick_fd = 0;
}

void Joystick::readEv()
{
	ssize_t bytes = read(joystick_fd, joystick_ev, sizeof(*joystick_ev));
	if (bytes == sizeof(*joystick_ev)) {
		joystick_ev->type &= ~JS_EVENT_INIT;
		if (joystick_ev->type & JS_EVENT_BUTTON) {
			joystick_st->button[int(joystick_ev->number)] = joystick_ev->value;
		}
		if (joystick_ev->type & JS_EVENT_AXIS) {
			joystick_st->axis[int(joystick_ev->number)] = joystick_ev->value;
		}

		// std::cout<<"joystick_ev->type  "<< (int)joystick_ev->type <<std::endl;
		// std::cout<<"joystick_ev->number  "<< (int)joystick_ev->number <<std::endl;



		if(buttonPressed(PUSH_BUTTON_LB)){
			isPause = !(isPause);

			if(isPause)
				ROS_INFO("JoyStick Pause.");
			else
				ROS_INFO("JoyStick Start.");
		}
		if(buttonPressed(PUSH_BUTTON_A)){
			ROS_INFO("diff");
			btn_last = btn_id;
			btn_id = PUSH_BUTTON_A;
			//btn_last = btn_id;

		}
		else if(buttonPressed(PUSH_BUTTON_B)){
			ROS_INFO("omni");
			btn_last = btn_id;
			btn_id = PUSH_BUTTON_B;
			//btn_last = btn_id;
		}
		else if(buttonPressed(PUSH_BUTTON_X)){
			ROS_INFO("turn_left");
			btn_last = btn_id;
			btn_id = PUSH_BUTTON_X;
			//btn_last = btn_id;
		}
		else if(buttonPressed(PUSH_BUTTON_Y)){
			ROS_INFO("turn_right");
			btn_last = btn_id;
			btn_id = PUSH_BUTTON_Y;
			//btn_last = btn_id;
		}
		else if(buttonPressed(PUSH_BUTTON_RB)){
			ROS_INFO("send charging");
			btn_last = btn_id;
			btn_id = PUSH_BUTTON_RB;
		}
		else if(buttonPressed(PUSH_BUTTON_START)){
			ROS_INFO("Start node");
			btn_id = PUSH_BUTTON_START;
		}
		else if(buttonPressed(PUSH_BUTTON_BACK)){
			ROS_INFO("send loading");
			btn_last = btn_id;
			btn_id = PUSH_BUTTON_BACK;
		}
		else if(buttonPressed(PUSH_BUTTON_LOGITECH)){
			ROS_INFO("LOGITECH");
			btn_last = btn_id;
			btn_id = PUSH_BUTTON_LOGITECH;
		}
		else if(buttonPressed(PUSH_BUTTON_LEFT_AXIS)){
			ROS_INFO("PUSH_BUTTON_LEFT_AXIS");
			btn_last = btn_id;
			btn_id = PUSH_BUTTON_LEFT_AXIS;
		}
		else if(buttonPressed(PUSH_BUTTON_RIGHT_AXIS)){
			ROS_INFO("PUSH_BUTTON_RIGHT_AXIS");
			btn_last = btn_id;
			btn_id = PUSH_BUTTON_RIGHT_AXIS;
		}

		joystick_position pos_buf;

		leftAxis = joystickPosition(0); // Axis[0] and Axis[1]
		rightAxis = joystickPosition(3); // Axis[0] and Axis[1]




		//Debug
		// cout<<"=========================================="<<endl;
		// cout<<"---Button---"<<endl;
		// for(int i=0; i<joystick_st->button.size(); i++)
		//     cout<<joystick_st->button[i]<<" ";
		// cout<<endl;

		// cout<<"----Axis----"<<endl;
		// for(int i=0; i<joystick_st->axis.size(); i++){
		//    cout<<"Axis["<<i<<"]: "<<joystick_st->axis[i]<<endl;
		// }
	}
	//====================================================================================//
}

ssize_t Joystick::recvtimeout(int ss, js_event *buf, int timeout)
{
	fd_set fds;
	int n;
	struct timeval tv;

	FD_ZERO(&fds);
	FD_SET(ss, &fds);

	tv.tv_sec = 0;
	tv.tv_usec = timeout;

	n = select(ss+1, &fds, NULL, NULL, &tv);
	if(n == 0) return -2; //timeout;
	if(n == -1) return -1; //error


	return read(ss, buf, sizeof(*joystick_ev));
}

joystick_position Joystick::joystickPosition(int n) {

	joystick_position pos;

	if (n > -1 && n < axes) {
		int i0 = n, i1 = n+1;
		float x0 = joystick_st->axis[i0]/32767.0f, y0 = -joystick_st->axis[i1]/32767.0f;
		float x  = x0 * sqrt(1 - pow(y0, 2)/2.0f), y  = y0 * sqrt(1 - pow(x0, 2)/2.0f);

		pos.x = x0;
		pos.y = y0;

		pos.theta = atan2(y, x);
		pos.r = sqrt(pow(y, 2) + pow(x, 2));
	} else {
		pos.theta = pos.r = pos.x = pos.y = 0.0f;
	}
	// if (n == 0)
	// 	std::cout << "Left Axis, x = " << pos.x << " , y = " << pos.y << " , theta = " << pos.theta << " , r = " << pos.r << std::endl;
	// else
	// 	std::cout << "Right Axis, x = " << pos.x << " , y = " << pos.y << " , theta = " << pos.theta << " , r = " << pos.r << std::endl;
	return pos;
}

bool Joystick::buttonPressed(int n) {
	return n > -1 && n < buttons ? joystick_st->button[n] : 0;
}

bool Joystick::checkPause()
{
	return isPause;
}

void Joystick::RevProcess(double receive_period)
{
	int Receive_Package_Size = 32;
	int counter = 5;
	ros::Rate r_receive(1.0 / receive_period);
	while(1){

		readEv();


		if(!(checkPause())){


			JoyStick::joystick msg;
			msg.btn_id = btn_id;
			msg.btn_last = btn_last;
			float x = leftAxis.x * 0 + leftAxis.y * 1;
			float y = leftAxis.x * -1 + leftAxis.y * 0;
			msg.x = x;
			msg.y = y;
			msg.z = 0.0;

			Point_data_publisher_.publish(msg);


			//if(btn_id == PUSH_BUTTON_RB || btn_id == PUSH_BUTTON_START)
			// if(btn_id == PUSH_BUTTON_START)
			// {
			// 	std::cout<<"btn_last "<<btn_last<<std::endl;
			// 	btn_id = btn_last;
			// 	std::cout<<"btn_id "<<btn_id<<std::endl;
			// }

			// std::cout<<"btn_last "<<btn_last<<std::endl;
			// std::cout<<"btn_id "<<btn_id<<std::endl;

			if((btn_id == PUSH_BUTTON_RB) || (btn_id == PUSH_BUTTON_BACK) || (btn_id == PUSH_BUTTON_START) || (btn_id == PUSH_BUTTON_LOGITECH))
			{
				if(btn_id != btn_last)
				{
					counter++;
					if(counter > 100)
					{
						counter = 0;
						btn_last = btn_id;
					}
						//btn_last = btn_id;
				}
				else
				{
					counter = 0;
					btn_id = PUSH_BUTTON_B;
				}

			}
		}

		r_receive.sleep();

	}

}

int main(int argc, char **argv)
{

	ros::init(argc, argv, "JoyStick");
	ros::Time::init();


	Joystick *js;


	if(argc < 2){

		ROS_INFO("usage: <Joystick Device Name> ");

		return 0;

	}
	else{

		js = new Joystick(argv[1]);
		if(js->active == false){

			ROS_INFO("Open failed ");
			return 0;

		}

	}

	ROS_INFO("JoyStick Start.");
	ros::spin();

	return 0;
}
