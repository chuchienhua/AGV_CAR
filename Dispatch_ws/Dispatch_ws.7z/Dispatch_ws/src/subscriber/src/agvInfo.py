#!/usr/bin/env python

import math
# import pyautogui
import os
import time

# shut_down = false

def new_window():
    pyautogui.hotkey('ctrl', 'alt', 't')
    time.sleep(3.0)



class agvInfo:
    def __init__(self):
        self.id = 0
        self.batterySOC = 0
        self.missionStatus = 0
        self.stopStatus = 0
        self.error = 0
        self.x_int = 0
        self.x_float_high = 0
        self.x_float_low = 0
        self.y_int = 0
        self.y_float_high = 0
        self.y_float_low = 0
        self.z_int = 0
        self.z_float_high = 0
        self.z_float_low = 0
        self.check_joystick = 0
        self.heart = 0

    def AGVStatusCallback(self, msg):
        self.id = msg.id
        self.batterySOC = msg.batterySOC
        self.missionStatus = msg.missionStatus
        self.stopStatus = msg.stopStatus
        self.error = msg.error
        self.check_joystick =msg.check_joystick
        self.heart = msg.heart

        # if(self.batterySOC <=47 and shut_down ==false):
        #     new_window()
        #     pyautogui.typewrite('sudo shutdown -h 2')
        #     pyautogui.hotkey('\n')
        #     time.sleep(2.0)
        #     pyautogui.typewrite('04126516')
        #     pyautogui.hotkey('\n')
        #     shut_down = true

        if(self.batterySOC <= 30):
            # os.system('sudo shutdown now')
            os.system('systemctl poweroff')
            

        # Position processing
        x = msg.x
        y = msg.y
        z = msg.z
        
        # position x encode into integer and fraction parts
        if x >= 0:
            self.x_int = int(math.floor(x))
            x_float = int((x % 1) * 1000)
        else:
            self.x_int = int(math.ceil(x))
            x_float = int((x % -1) * 1000)
        
        self.x_float_high = int(x_float / 256)
        self.x_float_low = int(x_float % 256)

        self.x_int += 128
        self.x_float_high += 128

        # position y encode into integer and fraction parts
        if y >= 0:
            self.y_int = int(math.floor(y))
            y_float = int((y % 1) * 1000)
        else:
            self.y_int = int(math.ceil(y))
            y_float = int((y % -1) * 1000)

        self.y_float_high = int(y_float / 256)
        self.y_float_low = int(y_float % 256)

        self.y_int += 128
        self.y_float_high += 128

        # position z encode into integer and fraction parts
        if z >= 0:
            self.z_int = int(math.floor(z))
            z_float = int((z % 1) * 1000)
        else:
            self.z_int = int(math.ceil(z))
            z_float = int((z % -1) * 1000)

        self.z_float_high = int(z_float / 256)
        self.z_float_low = int(z_float % 256)

        self.z_int += 128
        self.z_float_high += 128

    def statusEncode(self):
        #command = [83, 84, self.id, self.batterySOC, self.missionStatus, self.stopStatus, self.x_int, self.x_float_high, self.x_float_low, self.y_int, self.y_float_high, self.y_float_low, self.z_int, self.z_float_high, self.z_float_low, self.error, self.check_joystick, self.heart, 68]
        command = [83, 84, self.id, self.batterySOC, self.missionStatus, self.stopStatus, self.x_int, self.x_float_high, self.x_float_low, self.y_int, self.y_float_high, self.y_float_low, self.z_int, self.z_float_high, self.z_float_low, self.error, self.check_joystick, self.heart, 68]
        #command = [83, 84, self.id, self.batterySOC, self.missionStatus, self.stopStatus, self.x_int, self.x_float_high, self.x_float_low, self.y_int, self.y_float_high, self.y_float_low, self.z_int, self.z_float_high, self.z_float_low, self.error, 69, 78, 68]
        command_byte = bytearray(command)
        return command_byte