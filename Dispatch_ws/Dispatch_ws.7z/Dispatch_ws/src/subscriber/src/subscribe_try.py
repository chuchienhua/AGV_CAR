#!/usr/bin/env python

# ROS
import rospy
from subscriber.msg import stop
from subscriber.msg import AGVStatus

# Python Library
import threading
import socket
import time
import math

# Global Variables : AGVStatus Initialize
id = 0
batterySOC = 0
missionStatus = 0
stopStatus = 0
error = 0
x_int = 0
x_float_high = 0
x_float_low = 0
y_int = 0
y_float_high = 0
y_float_low = 0
z_int = 0
z_float_high = 0
z_float_low = 0

# Anhung UDP Server Initialize
Anhung_UDP = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
Anhung_UDP.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
Anhung_PORT = 9930
Anhung_network = "127.0.0.1"
print ("[Anhung  Control] UDP Connection Setting Finished.")

# Dispatch System TCP Server Initialize
Server_host = "192.168.72.98"
Server_port = 36000
Dispatch_System_TCP_server = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
Dispatch_System_TCP_server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) # Re-use address when there's address in use error
Dispatch_System_TCP_server.setblocking(0) # nonblocking

Dispatch_System_TCP_server.bind((Server_host, Server_port))
Dispatch_System_TCP_server.listen(10)
dispatch_socket, addr = Dispatch_System_TCP_server.accept()

def AGVStatusCallback(AGVStatus):
    global id, batterySOC, missionStatus, stopStatus, error
    global x_int, x_float_high, x_float_low
    global y_int, y_float_high, y_float_low
    global z_int, z_float_high, z_float_low

    id = AGVStatus.id
    batterySOC = AGVStatus.batterySOC
    missionStatus = AGVStatus.missionStatus
    stopStatus = AGVStatus.stopStatus
    error = AGVStatus.error

    # Position processing
    x = AGVStatus.x
    y = AGVStatus.y
    z = AGVStatus.z
    
    # position x encode into integer and fraction parts
    if x >= 0:
        x_int = int(math.floor(x))
        x_float = int((x % 1) * 1000)
    else:
        x_int = int(math.ceil(x))
        x_float = int((x % -1) * 1000)
    
    x_float_high = int(x_float / 256)
    x_float_low = int(x_float % 256)

    x_int += 128
    x_float_high += 128

    # position y encode into integer and fraction parts
    if y >= 0:
        y_int = int(math.floor(y))
        y_float = int((y % 1) * 1000)
    else:
        y_int = int(math.ceil(y))
        y_float = int((y % -1) * 1000)

    y_float_high = int(y_float / 256)
    y_float_low = int(y_float % 256)

    y_int += 128
    y_float_high += 128

    # position z encode into integer and fraction parts
    if z >= 0:
        z_int = int(math.floor(z))
        z_float = int((z % 1) * 1000)
    else:
        z_int = int(math.ceil(z))
        z_float = int((z % -1) * 1000)

    z_float_high = int(z_float / 256)
    z_float_low = int(z_float % 256)

    z_int += 128
    z_float_high += 128

    #print ("id = %d, batterySOC = %d, missionStatus = %d" % (id, batterySOC, missionStatus))
    #print ("stopStatus = %d, x = %f, y = %f, z = %f, error = %d" % (stopStatus, x, y, z, error))
    #print ("%f = %d + (%d + %d) / 1000" % (x, x_int, x_float_high, x_float_low) )

def dispatchReceive():
    global Dispatch_System_TCP_server, dispatch_socket

    pub = rospy.Publisher('stop', stop, queue_size=10)
    rate = rospy.Rate(10) #10hz
    msg = stop()
    msg.emergency = True

    last_command = ''
    last_command_time = 0

    while True:
        try:
            print "[Dispatch System] Waiting for mission ..."
            data = dispatch_socket.recv(16, socket.MSG_DONTWAIT)
            if data:
                if (data != last_command) or ((data == last_command) and ((time.time() - last_command_time) > 10)):
                    print "[Dispatch System] Command Received!"
                    print str(data)

                    if data == b'SGE':
                        Navigate()

                    last_command = data
                    last_command_time = time.time()
                
                if data == b'SHE':
                    rospy.loginfo(msg)
                    pub.publish(msg)
                    rate.sleep()
            #else:
                #dispatch_socket,addr = Dispatch_System_TCP_server.accept()
        except Exception as e:
            print e
            break
    print("dispatchReceive Thread Finish")
    Dispatch_System_TCP_server.close()
        
def statusUpload():
    global Dispatch_System_TCP_server, dispatch_socket
    global id, batterySOC, missionStatus, stopStatus, error
    global x_int, x_float_high, x_float_low
    global y_int, y_float_high, y_float_low
    global z_int, z_float_high, z_float_low

    rate = rospy.Rate(1) #1hz

    while True:
        try:
            command = [83, 84, id, batterySOC, missionStatus, stopStatus, x_int, x_float_high, x_float_low,y_int, y_float_high, y_float_low, z_int, z_float_high, z_float_low, error, 69, 78, 68]
            command_byte = bytearray(command)
            dispatch_socket.send(command_byte)
            rate.sleep()
        except Exception as e:
            print e
            break
    print("statusUpload Thread Finish")
    Dispatch_System_TCP_server.close()

def Navigate():
    print "[Dispatch System] Starts Navigation."
    Anhung_UDP.sendto('Mr;0,0,18.465,0.569,3.14,omni,0,1.0;1,3,18.465,-0.056,3.14,omni,0,1.0,0;2,3,8.933,0.0457,3.14,omni,0,1.0,0;3,3,7.202,-0.011,3.14,omni,0,1.0,0;4,4,2.517,0.0,3.14,omni,0,1.0,0;5,6,-0.591,0.259,3.14,omni,0,1.0,0;E'.encode('utf-8'), (Anhung_network, Anhung_PORT))

def main():
    rospy.init_node('transfer', anonymous=True)

    rospy.Subscriber("/AGVStatus", AGVStatus, AGVStatusCallback)

    # Receive Command
    receiveThread = threading.Thread(target = dispatchReceive)
    receiveThread.start()
    print("[Initialization ] Starts Subscribing Dispatch Missions.")

    # Upload Status
    uploadThread = threading.Thread(target = statusUpload)
    uploadThread.start()
    print("[Initialization ] Starts Uploading AGV Status.")
    
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()
    receiveThread.join()
    uploadThread.join()

if __name__ == '__main__':
    main()