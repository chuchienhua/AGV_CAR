#!/usr/bin/env python

import socket

class anhungUDP:
    def __init__(self):
        # Anhung UDP Server Initialize
        self.connection = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.connection.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        self.PORT = 9930
        self.IP_ADDR = "127.0.0.1"
        print ("[Anhung  Control] UDP Connection Setting Finished.")
    
    def pickUpA(self):
        missionPath = '/home/user/Dispatch_ws/missionPath/mission_A.txt'
        with open(missionPath) as f:
            lines = f.readlines()

        self.connection.sendto(lines[0].encode('utf-8'), (self.IP_ADDR, self.PORT))
        print ("[Anhung  Control] Pick up N2 Cart at FAB A.")
    
    def pickUpB(self):
        missionPath = '/home/user/Dispatch_ws/missionPath/mission_B.txt'
        with open(missionPath) as f:
            lines = f.readlines()

        self.connection.sendto(lines[0].encode('utf-8'), (self.IP_ADDR, self.PORT))
        print ("[Anhung  Control] Pick up N2 Cart at FAB B.")

    def chargeBattery(self):
        missionPath = '/home/user/Dispatch_ws/missionPath/mission_C.txt'
        with open(missionPath) as f:
            lines = f.readlines()

        self.connection.sendto(lines[0].encode('utf-8'), (self.IP_ADDR, self.PORT))
        print ("[Anhung  Control] Go to Charge the Battery.")
    
    def goBackIdle(self):
        missionPath = '/home/user/Dispatch_ws/missionPath/mission_D.txt'
        with open(missionPath) as f:
            lines = f.readlines()

        self.connection.sendto(lines[0].encode('utf-8'), (self.IP_ADDR, self.PORT))
        print ("[Anhung  Control] Go Back to Idle Position.")
    
