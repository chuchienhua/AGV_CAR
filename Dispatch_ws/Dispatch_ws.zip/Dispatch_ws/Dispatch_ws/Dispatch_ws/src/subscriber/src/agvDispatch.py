#!/usr/bin/env python

# ROS
import rospy
from subscriber.msg import stop
from subscriber.msg import AGVStatus

# Python Library
import threading
import argparse

# /src
import anhungUDP
import agvInfo
import dispatchTCP

parser = argparse.ArgumentParser()
parser.add_argument("IP", type=str, help = "AGV's IP Address.")
args = parser.parse_args()

def main():
    # ROS Init
    rospy.init_node('transfer', anonymous=True)

    # Class Init
    AnhungControl = anhungUDP.anhungUDP()
    AGVInfo = agvInfo.agvInfo()

    rospy.Subscriber("/AGVStatus", AGVStatus, AGVInfo.AGVStatusCallback)
    stopPub = rospy.Publisher("stop", stop, queue_size=10)
    
    DispatchTCP = dispatchTCP.dispatchTCP(stopPub, args.IP)

    # Upload Status
    uploadThread = threading.Thread(target = DispatchTCP.statusUpload, args = (AGVInfo,))
    uploadThread.start()
    print("[Initialization ] Starts Uploading AGV Status.")

    # Receive Command
    receiveThread = threading.Thread(target = DispatchTCP.commandReceive, args = (AnhungControl,))
    receiveThread.start()
    print("[Initialization ] Starts Subscribing Dispatch Missions.")

    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()
    receiveThread.join()
    uploadThread.join()

if __name__ == '__main__':
    main()
